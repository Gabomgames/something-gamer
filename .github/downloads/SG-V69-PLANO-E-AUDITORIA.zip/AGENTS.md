# Something Gamer — regras permanentes

## Produto e preservação

- Desenvolvedora: NOW Technologies. Trabalhe incrementalmente no código existente; não recrie o projeto nem remova funcionalidades para reduzir escopo.
- Preserve contas, IDs, publicações, servidores, mensagens, integrações e contratos de dados. Não execute reset, limpeza de banco, exclusão de conta ou migração destrutiva como parte de manutenção.
- Preserve Verificado Gamer, benefícios, aprovação administrativa e preços: 30 dias R$ 14,90; 180 dias R$ 79,90; 365 dias R$ 149,90. Pagamento confirmado não equivale a aprovação administrativa. Não transforme períodos avulsos em renovação automática.
- Slogan SG: "Something Gamer — Yes, Something for you ;)". Slogan NOW: "O futuro é agora ;)".
- Não crie botões sem ação real, funcionalidades simuladas no produto ou resultados de testes inventados. Fixtures isoladas de teste devem ser identificadas e nunca publicadas no produto/Hosting; podem ser versionadas junto aos testes no GitHub.
- Envie sempre os downloads pelo GitHub, conforme preferência explícita do usuário. Disponibilize o artefato no repositório autorizado e confirme o envio antes de apresentar o link; não substitua por download local nem invente URL de artefato ainda não enviado. Essa entrega não autoriza merge, deploy ou implementação de fase pendente.

## Autorização e segurança

- O trabalho V69 segue o plano em docs/v69/PLANO.md. Aguarde aprovação do plano; depois execute somente a fase autorizada, registre resultados e regressões reais e apresente o resultado antes de avançar.
- Não altere pagamentos reais, preços, flags, segredos, regras/índices publicados, domínios ou configurações de produção sem autorização explícita. Aprovação de código não autoriza deploy, migração remota ou cobrança.
- Use emuladores com projeto demo e dados sintéticos para testes. Nunca use contas reais, crie cobranças reais ou grave em produção para validar uma mudança.
- Não exponha dados pessoais, tokens ou credenciais em logs, testes, fixtures, relatórios ou Git. Use configurações seguras; verifique nomes/presença, nunca valores. Chaves públicas de configuração Firebase não são credenciais administrativas.
- Autoridade sobre selos, benefícios, pagamentos, moderação e cargos pertence ao servidor. Verifique autenticação, autorização por recurso, concorrência e idempotência.

## Trabalho e validação

- Use o checkout existente da tarefa isolada. Não crie Git worktree sem solicitação explícita.
- O ZIP V69 está extraído separadamente em /workspace/review-v69/Something-Gamer-V69. O checkout Git inicial é uma versão diferente. Não sobreponha as árvores automaticamente; siga o inventário e o plano de integração antes de importar.
- Preserve alterações preexistentes. Antes de cada fase, registre HEAD, diff, hashes e uma cópia recuperável. A estratégia está em docs/v69/BACKUP-REVERSAO.md.
- Consulte package.json, lockfiles, CI e requisitos de runtime da árvore efetivamente trabalhada. A V69 usa Node 22 na CI; Functions declaram Node 20. Não aplique o setup do checkout antigo à V69 sem revisão.
- Rode checks que exercitem a alteração e as regressões de contratos afetados. Distinga testes de texto, comportamento local, emulador, fixtures de navegador e homologação real. Não declare sucesso em suíte com zero testes, falhas ou bloqueios.
- Não mude asserts só para tornar o resultado verde. Falso positivo de ferramenta deve ser demonstrado e corrigido mantendo a detecção de erros reais.
- UX: preserve navegação e funcionalidades, use estados reais de carregamento/erro/vazio, foco por teclado, nomes acessíveis e layouts móveis sem sobreposição. Evite acrescentar camadas de CSS versionadas como solução permanente.
- Ao encerrar uma fase, documente arquivos/contratos alterados, checks executados e contagens, limitações, riscos e procedimento de reversão. Não avance automaticamente para outra fase.
